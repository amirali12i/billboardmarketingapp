// This component has been deprecated. Its functionality has been moved into the new
// primary/secondary navigation system managed by LeftPanel.tsx.
// This file is kept to prevent import errors in some environments but should be considered removed.
import React from 'react';

const RightPanel: React.FC = () => {
  return null;
};

export default RightPanel;
